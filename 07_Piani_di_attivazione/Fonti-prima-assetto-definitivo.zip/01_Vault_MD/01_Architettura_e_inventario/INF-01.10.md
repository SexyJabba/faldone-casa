---
codice: "INF-01.10"
titolo: "Memorie: disponibilita, distribuzione e utilizzo"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-01.10 · Memorie: disponibilita, distribuzione e utilizzo

Il conto definitivo distingue possesso e trattativa: quattro PC3L da 16 GB gia comprati per M2 (64 GB) e sei PC3L da 16 GB proposti su Vinted (96 GB). Offerta inviata 85 EUR, non accettazione o acquisto. Totale obiettivo delle tre D1581: 160 GB solo se il lotto viene acquisito.

| Nodo | Gruppo | Composizione | Capacita |
| --- | --- | --- | --- |
| M1 | INV-101 | 2 x 16 GB DDR4 RDIMM gia disponibili | 32 GB |
| M2 | INV-100 | 4 x 16 GB PC3L RDIMM gia posseduti | 64 GB |
| M3 | INV-075/099 | 8x16 GB DDR3 RDIMM | 128 GB |
| M4 | INV-076 | 4x8 GB ECC UDIMM | 32 GB |
| M5 | Lotto Vinted / 2 moduli | 2 x 16 GB PC3L-10600R RDIMM; acquisto non concluso | 32 GB previsti |
| M6 | Lotto Vinted / 4 moduli | 4 x 16 GB PC3L-10600R RDIMM; acquisto non concluso | 64 GB previsti |
| M7 | INV-039 | 2x8 GB HyperX | 16 GB |
| S1 | Hynix PC3-10600U-9-11-B1 | 2x4 GB 2Rx8, esemplari da associare | 8 GB |
| S3/S4 | Wyse 3030 | 4 GB ciascuno dichiarati; 32 GB storage da riscontro | 4 GB ciascuno |
| Scorta RDIMM16 GB | INV-075/099 | 13 DDR3 - 8 M3 = 5; vecchia assegnazione M6 liberata nel progetto | 80 GB PC3; non sostitutivi automatici dei PC3L |
| C1 | DDR4 SO-DIMM | RAM censita8 GB senza LLM | 8 GB |
| C2 | DDR4 SO-DIMM | RAM censita8 GB | 8 GB |
| C3 | DDR4 SO-DIMM | Base16 GB per HA; misura risorse | 16 GB |
| C4 | DDR4 SO-DIMM | Base16 GB per HA; misura risorse | 16 GB |
| MP2 | Apple Silicon unificata | Scenario di scambio, non RAM disponibile obbligatoria | 8 GB |
| MP3 | Aspire 7 | Dotazione dichiarata, composizione slot da verificare | 16 GB |

## Perche 64 / 32 / 64

M2 conserva i quattro moduli gia posseduti. Due nuovi moduli vanno a M5 e quattro a M6. L'utente preferisce utilizzare tutti i banchi; 48/48 rimane un'alternativa tecnica da verificare secondo regole di popolamento, ma la base 4.4 concentra piu margine sul nodo dati/media. I 64 GB di M6 sono una riserva utile, non un fabbisogno misurato.

M1 usa i 32 GB DDR4 gia disponibili: OPNsense 8 GB iniziali, VM monitoraggio 4-8 GB, resto a host e margine. M2 parte con ARC massimo proposto 16 GB se ZFS e sull'host; assegnazioni guest complessive iniziali entro 36 GB e almeno 12 GB per host/margine. Sono budget di progetto da correggere con misure, non memoria da occupare per forza.

M5: 8 GB HAOS, 2 GB MQTT, 10 GB Frigate/gateway come budget iniziale, 4 GB host/cache e 8 GB margine. M6: servizi entro 24 GB, ARC fino a 16 GB iniziali sul pool locale, 8 GB host e 16 GB margine; aumentare ARC solo se le letture ripetute lo giustificano. Cache e limiti guest non devono essere conteggiati due volte. La cache di M6 non e l'ARC dei dischi di M4.

M4 puo iniziare con ARC 8-12 GB e margine per backup e filesystem. M3 conserva 128 GB, utili per lotti e modelli in RAM ma non equivalenti a VRAM della RTX3060. Nessuna cache deve essere unica copia di dati persistenti. Un RAM disk e ammesso solo per temporanei ricreabili, con limite.

Le etichette PC3L-10600R indicano RDIMM a bassa tensione, non ECC UDIMM. Non spostare RDIMM sulla P9D senza compatibilita. I cinque moduli PC3 residui previsti dal vecchio lotto non sostituiscono automaticamente PC3L.

[Proxmox ZFS e ARC](https://github.com/proxmox/pve-docs/blob/master/local-zfs.adoc) · [OpenZFS cache](https://openzfs.github.io/openzfs-docs/Basic%20Concepts/Pool%20Structure/Caching.html)

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

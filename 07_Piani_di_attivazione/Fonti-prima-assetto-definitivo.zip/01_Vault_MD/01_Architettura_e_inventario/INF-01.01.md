---
codice: "INF-01.01"
titolo: "Architettura e apparati della revisione 4.4"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-01.01 · Architettura e apparati della revisione 4.4

La 4.4 e una configurazione di progetto, non un verbale di installazione. Acquisti e riscontri sono distinti in [[REV3-STATO]]. Le tre D1581 sono in arrivo; la RAM Vinted e ancora in trattativa.

Il nucleo stabile proposto comprende M1, M2, M5, C3 e C4: cinque voti, quorum tre. M3, M4 e M6 sono host Proxmox autonomi accesi secondo necessita. S4 osserva e invia WoL senza voto. Il Vito e un nodo mobile indipendente, non un membro del cluster.

| Apparato | Piattaforma | Memoria e storage | Responsabilita | Identita |
| --- | --- | --- | --- | --- |
| M1 | MACHINIST X99 PR9-H / Xeon v4 dichiarato, SKU da identificare | 32 GB DDR4 ECC RDIMM, 2 x 16, disponibili | Proxmox: OPNsense VM e osservabilita separata; nucleo sempre acceso | INV-101 RAM / nuova scheda da associare |
| M2 | D1581-Q3A / Xeon D-1581, assegnazione di progetto | 64 GB PC3L RDIMM, 4 x 16 gia posseduti | Proxmox: app personali; P310 4 TB provvisorio dopo liberazione Arca; nucleo sempre acceso | INV-100 / 005 / 009 / Q3A nuova |
| M3 | HUANANZHI X99-T8 / E5-2678 v3 | 128 GB, 8 x 16 DDR3 RDIMM | Proxmox autonomo IA su richiesta; RTX 3060 12 GB; nessun voto nel nucleo | INV-030 / 048 / 077 |
| M4 | ASUS P9D-MH/SAS/10G-DUAL / E3-1265L v3 | 32 GB, 4 x 8 ECC UDIMM | Proxmox autonomo/ZFS: WD solo backup dopo transizione; media separati, acceso per richiesta/job | INV-073 / 047 / 076 |
| M5 | D1581-Q3 / Xeon D-1581, assegnazione condizionata al bus Hailo | 32 GB PC3L RDIMM, 2 x 16 dal lotto ancora in trattativa | Proxmox: HAOS, MQTT, Frigate/Hailo; nucleo sempre acceso | INV-074 / lotto RAM nuovo / INV-098 candidato |
| M6 | D1581-Q3A / Xeon D-1581, assegnazione condizionata a GPU e NIC | 64 GB PC3L RDIMM, 4 x 16 dal lotto ancora in trattativa | Proxmox autonomo: media, Seafile, download; acceso a richiesta | Q3A nuova / Arc candidata / INV-097 |
| M7 | ASUS H61M-K / E3-1220L v2 | 16 GB, 2 x 8 DDR3 | Riserva manuale H61M-K; T110 II acquistato candidato sostitutivo, da qualificare | INV-033 / 046 / 039 |
| S1 | ASRock Q1900M / Celeron J1900 | 8 GB, 2 x 4 Hynix PC3-10600U | Linux: Caddy, Vaultwarden, notifiche e utilita; fuori cluster | INV-034 / 049 / 041, esemplari da associare |
| S2 | Oracle Cloud Always Free, candidata A1 | Proposta: 1 OCPU / 4 GB / boot 50 GB | Osservazione esterna e relay; attivazione successiva; niente voto | Piano Oracle; nessun account/VM attivato qui |
| S3 | Dell Wyse 3030 N03D | 4 GB / 32 GB dichiarati | Linux: Sonoff ZBDongle-P, Zigbee2MQTT e dashboard leggera; fuori cluster | Prodotto/seriale da associare, Wyse radio |
| S4 | Dell Wyse 3030 N03D | 4 GB / 32 GB dichiarati | Sentinella indipendente e primo mittente WoL; nessun voto nella base 4.4 | Wyse sentinella, codice esemplare da associare |
| C1 | Dell OptiPlex 7070 Ultra / i5-8265U | 8 GB censiti, nessun LLM locale | Vito W639: nodo mobile lavoro/camper autonomo; offline, LTE e recupero; fuori quorum | INV-079, esemplare C1 |
| C2 | Dell OptiPlex 7070 Ultra / i5-8265U | 8 GB censiti, espansione solo se necessaria | Cucina: client Linux, streaming/Moonlight e pannello casa | INV-079, esemplare C2 |
| C3 | Dell OptiPlex 7070 Ultra / i5-8265U | 16 GB base HA, riscontro risorse | Proxmox client Linux e subentro HAOS/MQTT, senza Hermes | INV-079, esemplare C3 |
| C4 | Dell OptiPlex 7070 Ultra / i5-8265U | 16 GB base HA, riscontro risorse | Proxmox nucleo: client Linux, riserva app selezionate, secondo mittente WoL | INV-079, esemplare C4 |
| MP3 | Acer Aspire 7 A715-42G-R2VB / Ryzen 7 5700U / RTX3050 Ti 4 GB | 16 GB / Crucial P3 Plus1 TB | Acer sempre fisso in laboratorio: Windows lavoro/gioco, Sunshine; OpenClaw di lavoro e Hermes da predisporre | MP3, codice INV da associare; dotazione dichiarata utente |
| MP2 | Apple MacBook Air M1 | 8 GB / SSD256 GB | Scambio ancora in sospeso: opzione MacBook Air, non postazione necessaria della 4.3 | INV-096, esemplare MP2 |
| MP4 | ASUS X99-DELUXE / i7-5930K / RTX2080 | 32 GB DDR4 | PC primo fratello, esterno all’infrastruttura | INV-029/043/035/055 |
| MP5 | ASRock X79 Extreme3 / i7-3820 | DDR3UDIMM, taglio e altri pezzi da associare | Ipotesi PC secondo fratello subordinata allo scambio Air ancora in sospeso; kit X79 da testare | INV-031/044; nessun componente server sottratto |
| Wyse laboratorio | Dell Wyse 3030 N03D | 4 GB / 32 GB dichiarati | Jellyfin, musica e pannello Home Assistant; affianca Acer | Codice C e INV da associare |
| Wyse studio | Dell Wyse 3030 N03D | 4 GB / 32 GB dichiarati | Monitor e client audio verso Behringer CONTROL2USB | Codice C e INV da associare |
| Wyse Hi-Fi salone | Dell Wyse 3030 N03D | 4 GB / 32 GB dichiarati | Client Hi-Fi verso DAC ES9038Q2M USB | Codice C e INV da associare |
| HP amico 1 | HP t520 | 4 GB / Apacer M.2 8 GB | Client esterno Ethernet: LibreELEC, Jellyfin e offline USB | INV-078, codice CE e seriale da associare |
| HP amico 2 | HP t520 | 4 GB / Apacer M.2 8 GB | Client esterno Ethernet: LibreELEC, Jellyfin e offline USB | INV-078, codice CE e seriale da associare |
| Microtech ingresso | Microtech EBL14B | Dotazione da riscontrare; modello 4 GB/64 GB eMMC | Pannello citofono/allarme, display e batteria integrati; fuori cluster | Codice MP/INV e seriale da associare |
| T110 II | Dell PowerEdge T110 II / E3-1220 v2 | 8 GB dichiarati | Riserva candidata per M7 e disponibilita unita RDX SATA | Prodotto/seriale da associare; lotto acquistato 150 EUR |
| Kindle recuperato | Kindle 11a generazione USB-C | Modello base/Paperwhite da associare | Biblioteca tecnica e plancia compatta; dispositivo personale | Codice MD/INV da associare |

Le assegnazioni Q3/Q3A si chiudono dopo il controllo dei bus: M2 richiede due NVMe simultanei e Mellanox; M5 un percorso Hailo con boot SATA; M6 GPU e NIC simultanee. Prima di comprare adattatori si verificano schede ricevute e revisione. [[REV4-PCIE]] · [[REV4-RAM]] · [[REV4-VITO]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

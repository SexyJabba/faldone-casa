---
codice: "INF-01.08"
titolo: "Dell OptiPlex 7070 Ultra / scheda modello"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-01.08 · Dell OptiPlex 7070 Ultra / scheda modello

| Voce | Specifica e dotazione |
| --- | --- |
| Identità | Quattro Dell OptiPlex 7070 Ultra; regulatory type D13U001 dichiarato. CL-01/02/03/04 sono identificativi di progetto; Service Tag e assegnazione fisica nel registro identità. |
| CPU installata | Intel Core i5-8265U su ciascuno dei quattro esemplari, dichiarato da Alessandro. Riferimento tecnico: 4 core / 8 thread, UHD 620. [HW2] |
| RAM | Su ciascun Dell: 1x8 GB DDR4 a2400MHz. Due slot SODIMM nel riferimento di famiglia. [HW3] |
| Disco | SSD da 256 GB su uno slot M.2 su ciascun Dell, dichiarato; Wi-Fi sull’altro slot M.2. Modello/interfaccia SSD e seriale nel registro identità. Questi quattro SSD sono distinti dai quattro NVMe ordinati per M2/M3. |
| Porte video / USB | 2 USB-C Gen 2 con DisplayPort Alt Mode; 3 USB-A, di cui 2 Gen 2 e 1 Gen 1. Niente presa HDMI o DisplayPort a grandezza piena. [HW8] |
| Rete e audio | Wi-Fi su slot M.2 presente su tutti e quattro gli esemplari, dichiarato; chipset e Bluetooth nel registro identità, non inferiti. Riferimento di famiglia: RJ45 Gigabit e jack audio universale, nessun altoparlante interno. [HW1] |
| Alimentazione | Adattatore 65 W, 19,5 V / 3,34 A oppure alimentazione dalla USB-C posteriore con monitor PD compatibile. Non scambiare a caldo le fonti di alimentazione. [HW1] |
| Ingombro | 96,10 × 256,20 mm; spessore 19,70 mm senza HDD o 27,74 mm con HDD; peso massimo dichiarato 0,65 kg, variabile con dotazione. [HW1] |

UHD 620 decodifica H.264 e HEVC, compreso il profilo 10 bit assegnato dalla matrice Intel; non dispone di decodifica hardware AV1. La disponibilità effettiva dipende dal driver e dal client. RTX 2080 e questi endpoint lavorano sui profili H.264/HEVC. [HW4]

Conferma Alessandro 2026-10-11: la dotazione descritta è comune a tutti e quattro i Dell ordinati. Non significa distro già installate, prestiti eseguiti o consegne avvenute.

C1 e destinato al Vito W639; C2-C4 sono cucina, camera e salone. Il laboratorio usa Acer MP3 e Wyse media. LAN cablata e collegamenti per stanza sono registrati per esemplare; il laboratorio usa Windows su MP3 Aspire; lo studio un Wyse verso Behringer CONTROL2USB. Il costo storico complessivo è350 euro.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "INF-01.19"
titolo: "Catalogo prodotti INV e aggiunte da associare"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-01.19 · Catalogo prodotti e assegnazioni

| Codice | Prodotto / quantita | Assegnazione | Stato |
| --- | --- | --- | --- |
| INV-001 | Western Digital WD10EAVS 1 TB / 8 | 6WD10EAVS a M4 RAIDZ2; 2riserva | ASSEGNAZIONE DI CONFIGURAZIONE |
| INV-002 | Western Digital WD10EZRX 1 TB / 2 | 2WD10EZRX mirror M6 Seafile/audio | ASSEGNAZIONE DI CONFIGURAZIONE |
| INV-003 | Samsung 850 EVO 250 GB / 1 | M5 boot | RECUPERABILE CONFERMATO |
| INV-004 | Kingston SSDNow V300 120 GB / 1 | M6 boot | RECUPERABILE CONFERMATO |
| INV-005 | Crucial P310 4 TB + Lexar E750 / 1 | Arca fino a gate migrazione, poi M2 dati provvisori | CENSITO |
| INV-006 | Western Digital PC SN530 512 GB / 1 | M3 / Proxmox e IA | CENSITO |
| INV-007 | Kingston SSDNow V200 120 GB / 1 | M1 boot | RECUPERABILE CONFERMATO |
| INV-008 | Samsung 850 EVO 500 GB / 1 | M6 download/staging | CENSITO |
| INV-009 | Sabrent Rocket 512 GB / 1 | M2 / boot | CENSITO |
| INV-010 | Western Digital WD3200AAJS 320 GB / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-011 | Western Digital WD1601ABYS 160 GB / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-012 | Western Digital WD1600AAJS 160 GB / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-013 | Seagate ST1000LM024 1 TB / 2 | M5 / registrazioni Frigate | STATO DA INVENTARIO |
| INV-014 | HGST Z7K500-500 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-015 | Hitachi Z5K500-500 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-016 | HGST Z5K500-500 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-018 | corsair flash voyager slider / 1 | Non assegnato / magazzino | CENSITO |
| INV-019 | lexar ljds73-16g / 1 | Non assegnato / magazzino | CENSITO |
| INV-020 | verbatim usb 2.0 / 2 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-021 | kingston data traveler 100g3 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-022 | tdk 16gb / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-023 | tohaoll u1 v10 hc / 1 | Non assegnato / magazzino | CENSITO |
| INV-024 | kingston sdc10g2/64gb / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-025 | lexar 800x pro / 1 | Non assegnato / magazzino | CENSITO |
| INV-026 | generic / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-027 | generic class 6 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-028 | generic class 4 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-029 | ASUS X99-DELUXE / 1 | MP4, PC primo fratello nella configurazione 4.2 | STATO DA INVENTARIO |
| INV-030 | HUANANZHI X99-T8 / 1 | M3 | STATO DA INVENTARIO |
| INV-031 | ASRock X79 Extreme3 / 1 | Kit X79 da testare; scenario MP5 condizionato a scambio Air | DA TESTARE / ASSEGNAZIONE DI CONFIGURAZIONE |
| INV-032 | MSI H97M-ECO / 1 | Vecchio M1; riserva dopo migrazione verificata | STATO DA INVENTARIO |
| INV-033 | ASUS H61M-K / 1 | M7 / router di riserva manuale | STATO DA INVENTARIO |
| INV-034 | ASRock Q1900M / 1 | S1 / utilita locali | STATO DA INVENTARIO |
| INV-035 | G.Skill F4-2666C15Q-32GVR / moduli 8 GB / 4 | MP4, PC primo fratello nella configurazione 4.2 | CENSITO |
| INV-036 | ELPIDA 4 GB 2Rx4 PC3-10600R-9-10-E1 / 5 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-037 | hynix 4 GB 2Rx4 PC3-10600R-9-10-E1 / 9 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-038 | Kingston HyperX DDR3 4 GB / 8 | Vecchio M1, quattro moduli da liberare dopo transizione | SALDO CON RISERVA PROPOSTA |
| INV-039 | Kingston HyperX DDR3 8 GB / 2 | M7 / 2 moduli | STATO DA INVENTARIO |
| INV-040 | 99u5474-038.a00lf / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-041 | hynix 4gb 2rx8 pc3-10600u-9-11-b1 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-042 | nanya nt2gc72b8pa0nf-cg / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-043 | Intel Core i7-5930K / 1 | MP4, PC primo fratello nella configurazione 4.2 | STATO DA INVENTARIO |
| INV-044 | Intel Core i7-3820 / 1 | Kit X79 da testare; scenario MP5 condizionato a scambio Air | DA TESTARE / ASSEGNAZIONE DI CONFIGURAZIONE |
| INV-045 | Intel Xeon E5-2630L v2 / 1 | M6 / CPU1, secondo socket vuoto | STATO DA INVENTARIO |
| INV-046 | Intel Xeon E3-1220L v2 / 1 | M7 / router di riserva manuale | STATO DA INVENTARIO |
| INV-047 | Intel Xeon E3-1265L v3 / 1 | M4 | STATO DA INVENTARIO |
| INV-048 | Intel Xeon E5-2678 v3 / 1 | M3 | STATO DA INVENTARIO |
| INV-049 | Intel Celeron J1900 / 1 | S1 / CPU saldata alla Q1900M | STATO DA INVENTARIO |
| INV-050 | be quiet! Dark Power Pro 850 W / 1 | M3 | STATO DA INVENTARIO |
| INV-051 | Cooler Master RS-700-ASAB-L3 / 1 | M4 | STATO DA INVENTARIO |
| INV-052 | Thermaltake Smart SE SPS-730M / 1 | Mappa boot / alimentazione / telai da completare; non contato libero con certezza | STATO DA INVENTARIO |
| INV-053 | Corsair CX500 CP-9020047 / 1 | M2 | STATO DA INVENTARIO |
| INV-054 | FSP ATX-350PNF / 2 | Mappa boot / alimentazione / telai da completare; non contato libero con certezza | STATO DA INVENTARIO |
| INV-055 | ZOTAC GeForce RTX2080 Blower 8 GB / 1 | MP4, PC primo fratello nella configurazione 4.2 | STATO DA INVENTARIO |
| INV-057 | Gigabyte GV-N970G1 GAMING-4GD / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-058 | Sapphire Radeon HD6570 4 GB / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-059 | Case rack 4U / telaio INV-059 / 1 | Mappa boot / alimentazione / telai da completare; non contato libero con certezza | CENSITO |
| INV-060 | Case rack 4U / telaio INV-060 / 1 | M3 / telaio | CENSITO |
| INV-061 | Case rack 4U / telaio INV-061 / 1 | M1 / telaio | CENSITO |
| INV-062 | Case rack 4U / telaio INV-062 / 1 | Mappa boot / alimentazione / telai da completare; non contato libero con certezza | CENSITO |
| INV-063 | Case rack 4U / telaio INV-063 / 1 | Mappa boot / alimentazione / telai da completare; non contato libero con certezza | CENSITO |
| INV-064 | HP ProLiant DL180 G6 / frontale e 10 tray / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-065 | Intel EXPI9301CTBLK / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-066 | Intel EXPI9300PTBLK / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-067 | LSI SAS9207-8i / 1 | Riserva futuro pool SSD M2 | STATO DA INVENTARIO |
| INV-068 | HP NC380T / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-069 | Fenvi FV-AC1200 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-070 | Fenvi FV-AXE3000 / 1 | Non assegnato / magazzino | STATO DA INVENTARIO |
| INV-071 | ASUS Hyper M.2 X4 / 1 | Magazzino | STATO DA INVENTARIO |
| INV-072 | Intel Core i5-4570T / 1 | Vecchio M1; riserva dopo migrazione verificata | CONFIGURAZIONE |
| INV-073 | ASUS P9D-MH/SAS/10G-DUAL / 1 | M4 | RICEVUTA - DICHIARATO 2026-10-28 |
| INV-074 | D1581-Q3 / Intel Xeon D-1581 / 1 | M5 candidato, Q3 in arrivo | IN ARRIVO DICHIARATO |
| INV-075 | Lotto Samsung DDR3 RDIMM16 GB PC3, MPN per esemplare da etichetta / 7 | Lotto condiviso con INV-099: 8 moduli M3, 4 M6, 1 residuo complessivo | DISPONIBILITA DICHIARATA / IDENTITA INCOMPLETA |
| INV-076 | DDR3 ECC UDIMM 8 GB / codice modulo richiesto / 4 | M4 | IDENTITA INCOMPLETA |
| INV-077 | MSI GeForce RTX3060 Ventus2X 12 GB / 1 | M3 IA | RICEVUTA E MONTATA SU M3 - DICHIARATO 2026-10-26 |
| INV-078 | HP t520 / 2 | Due client esterni per amici; LibreELEC/Jellyfin/offline USB | CONFIGURAZIONE |
| INV-079 | Dell OptiPlex 7070 Ultra / Intel Core i5-8265U / 4 | Quattro 7070: Vito, cucina, camera, salone | CONFIGURAZIONE |
| INV-080 | Mellanox MNPA19-XTR / 1 | Due kit ordinati: NIC M3/M6; AOC 3 m per M2-M3 e M2-M4 | ORDINATO - NON ANCORA RICEVUTO ALLA CONFERMA 2026-10-28 |
| INV-081 | Mellanox MCX312A-XCBT / 1 | M2 | CONFIGURAZIONE |
| INV-082 | GLOTRENDS I226-T4 / 1 | M1 | CONFIGURAZIONE |
| INV-083 | NVIDIA Quadro NVS290 / variante bus da identificare / 2 | Magazzino / console | IDENTITA INCOMPLETA |
| INV-084 | Samsung PM991a 256 GB / 2 | Ripartizione M3 / SH da associare | CONFIGURAZIONE |
| INV-085 | Samsung PM991 256 GB / 1 | Ripartizione M3 / SH da associare | CONFIGURAZIONE |
| INV-086 | Intenso 3835440 PCIe Premium 250 GB / 1 | SH3 | CONFIGURAZIONE |
| INV-087 | Seagate ST2000DM008 2 TB / 4 | M4 / media | CONFIGURAZIONE |
| INV-088 | SSD enterprise480/500 GB di riferimento per M2; SKU da scegliere / 8 | M2 / quattro mirror | DA ACQUISTARE |
| INV-089 | ORICO USB 10Gb/s / bridge RTL9210B-CG / 1 | SH3 / box | CONFIGURAZIONE |
| INV-090 | NETGEAR GS305E / 1 | Rete / ruolo di switch nel registro | CONFIGURAZIONE |
| INV-091 | Google Pixel 7 / 1 | MD1 | CONFIGURAZIONE |
| INV-092 | Google Pixel 10 Pro / 1 | MD2 | CONFIGURAZIONE |
| INV-093 | Apple iPhone 11 / 1 | MD3 | CONFIGURAZIONE |
| INV-094 | Apple iPad / modello richiesto / 1 | MD4 | IDENTITA INCOMPLETA |
| INV-095 | Apple Mac Book principale / modello richiesto / 1 | MP1 | IDENTITA INCOMPLETA |
| INV-096 | Apple MacBook Air M1 / 8 GB / 256 GB / 1 | Scambio Air M1 in sospeso; non postazione obbligatoria 4.3 | SCAMBIO IN SOSPESO |
| INV-097 | Intel Arc A310 / produttore e SKU da indicare / 1 | M6 / Jellyfin | DA ACQUISTARE |
| INV-098 | Hailo-8 / SKU e key da indicare / 1 | M5 / Frigate e vision-gateway | NON ACQUISTATO |
| INV-099 | Kingston KVR16R11D4/16, 16GB2Rx4 PC3-12800R 1.5V / 6 | Lotto condiviso con INV-075: 8 moduli M3, 4 M6, 1 residuo complessivo | DISPONIBILITA DICHIARATA / IDENTITA INCOMPLETA |
| INV-100 | DDR3L 16 GB RDIMM:Micron MT36KSF2G72PZ-1G6E1HF e Samsung M393B2G70DB0-YK0 da foto / 4 | M2 4 x16 GB PC3L | GIA POSSEDUTO, CONFERMA UTENTE 1 NOVEMBRE |
| INV-101 | DDR4 PC4 ECC RDIMM 16 GB / produttore, MPN e velocita da indicare / 2 | M1 32 GB DDR4 ECC RDIMM | DISPONIBILE DICHIARATO 1 NOVEMBRE |
| INV-102 | BKHD C612NP-21 VER1.1 / 1 | Nessuna: ordine BKHD annullato | ORDINE ANNULLATO |
| INV-103 | Intel Xeon E5-2630L v3 / 1 | Nessuna: ordine BKHD annullato | ORDINE ANNULLATO |
| INV-104 | ASUS Z9PR-D12 / 1 | Candidata storica scartata; non riutilizzare il codice | CANDIDATA SCARTATA / NON ACQUISTATA |
| DA-ASSOCIARE-T110-II | Dell PowerEdge T110 II / E3-1220 v2 / 8 GB / 1 | Candidato riserva M7 | ACQUISTO DICHIARATO |
| DA-ASSOCIARE-RDX | RDX QuikStor SATA / generazione da associare / 1 | Copie offline candidate | ACQUISTO DICHIARATO |
| DA-ASSOCIARE-WYSE3030 | Dell Wyse 3030 N03D / 4 GB / 32 GB dichiarati / 5 | Laboratorio; S3; S4; studio; Hi-Fi salone | ACQUISTO DICHIARATO |
| DA-ASSOCIARE-ACER | Acer Aspire 7 A715-42G-R2VB / dotazione dichiarata / 1 | MP3 fisso laboratorio | RIENTRATO - SCAMBIO APPROVATO |
| DA-ASSOCIARE-EBL14B | Microtech EBL14B / 1 | Ingresso: pannello citofono/allarme | RECUPERATO |
| DA-ASSOCIARE-KINDLE | Kindle 11a generazione USB-C, modello da associare / 1 | Biblioteca/plancia personale | RECUPERATO |
| DA-ASSOCIARE-K19S | Dock regolamentare K19S, variante da associare / 1 | Postazioni casa | DISPONIBILE DICHIARATO |

Le nuove aggiunte A44 hanno identificativo provvisorio nel registro acquisti; non riutilizzare un codice INV esistente. [[REV3-ACQ]]

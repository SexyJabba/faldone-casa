---
codice: "INF-01.03"
titolo: "Alimentatori, telai e assemblaggio"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-01.03 · Alimentatori, telai e assemblaggio

Cinque case4U censiti:due profondi46cm, tre ex ATM37cm secondo fonti; associazione ai singoli INV da riscontro. Unrack aggiuntivo50 EUR usato, non scelto. M7 e Deluxe hanno casepropri. S1 riusa chassis HPDL380G6accorciato; M4 frontale10tray3,5senza backplane. Vecchio INV064DL180G6da riconciliare, non duplicare chassis o rinominare prodotto per ipotesi. Cavi dichiarati6/8SATAda1m sono dati, alimentazioni corrispondenti disponibili; connettori controllerda verificare.

Sei ATX censiti:bequiet850 W, Cooler Master700 W, Thermaltake730 W, Corsair CX500,2FSP350 W. Aggiunti Delta DPS250AB49L ebackplane AC0632A con 2DPS750RBA. Ilgruppo ridondante e una possibile soluzione per un nodo, non due ATXstandard o1500Wridondanti garantiti. Pinout/start/standby/ATX-EPS ecompatibilita non attestati: nessun cablaggioelettrico inventato.

Ripartizione PSU/boot/telai resta nelprospetto diassemblaggio, con proposte distinte dalle assegnazioni approvate. Prima saldoesemplari, poinuoviacquisti; alimentatori Dell/HPclient separati dagli ATX. Nessuna scheda videodeve essere comprata solo per console; M7 puo usare NVS290PCIex1 gia disponibile, con verifica del percorso console scelto.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-MAP]] · [[REV3-OPEN]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

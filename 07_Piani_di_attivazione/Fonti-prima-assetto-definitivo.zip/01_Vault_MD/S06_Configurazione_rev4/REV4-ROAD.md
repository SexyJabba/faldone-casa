---
codice: "REV4-ROAD"
titolo: "Roadmap: da Natale 2026 alla configurazione collaudata"
revisione: "4.4"
aggiornato: "2026-11-01"
---

# REV4-ROAD · Roadmap: da Natale 2026 alla configurazione collaudata

Le finestre sono indicative: partenza dalle vacanze di Natale, assunta dal 23 dicembre 2026, senza impegni prima. Le date dei passaggi distruttivi dipendono dai gate; un upload multi-terabyte su FTTC puo spostare il termine oltre marzo. Hardware e Vito possono procedere in parallelo senza cancellare i dati.

## 23-27 dicembre 2026 — Inventario e prove da banco

Sapere che cosa funziona prima di cambiare la casa.

- Confermare arrivi, ordine RAM e identificativi delle tre D1581
- Provare RAM, NVMe simultanei, NIC, temperature e avvio senza GPU
- Misurare tutti i dati, inclusi media sui WD e contenuti unici Arca
- Preparare C1 Vito da banco: SSD, alimentazione, display e kit offline

**Si passa oltre quando:** Inventario riconciliato, dischi identificati e prove annotate. Nessuna cancellazione.

**Ritorno possibile:** Tutto il sistema precedente resta disponibile.

## Dal 27 dicembre 2026 · durata dalla banda — Arca di transizione su Drive

Conservare tutti i dati prima di liberare i dischi.

- Definire cifratura e perimetro delle cartelle in un lavoro separato
- Caricare per lotti con registro esiti e controllo integrita
- Mantenere copia locale indipendente del nucleo irrinunciabile
- Provare ripristino file e applicazione; completare ultimo incremento

**Si passa oltre quando:** Ogni sorgente da ricostruire ha copia completa verificata e recuperabile.

**Ritorno possibile:** Sorgenti originali conservate; ripresa dei lotti falliti senza spostamenti.

## 28 dicembre 2026 - 6 gennaio 2027 · se pronti — Rete e nucleo stabile

Costruire il nuovo nucleo senza dipendere dai server a richiesta.

- Allestire M1 e provare OPNsense, NIC e recupero locale
- Creare nucleo Proxmox M1/M2/M5/C3/C4 a cinque voti
- Installare monitoraggio separato su M1 e sentinella S4
- Collegare M3/M4/M6 come host autonomi; nessun Corosync sul Vito

**Si passa oltre quando:** Rete ripristinabile, quorum controllato e accesso gestione disponibile anche a router fermo.

**Ritorno possibile:** Vecchio firewall o avvio bare metal; importare configurazione verificata.

## Gennaio 2027 o dopo il completamento delle copie — Dati e applicazioni

Liberare il P310 e spostare i dati sulle destinazioni definitive.

- Trasferire P310 da Arca a M2 soltanto dopo gate copie
- Ripristinare app e database; misurare latenza, RAM e spazio
- Evacuare media WD verso pool media collaudato; ricostruire WD per backup
- Provare backup locale e recupero selettivo; introdurre RDX se acquistati

**Si passa oltre quando:** Dati confrontati, applicazioni provate e almeno un recupero eseguito.

**Ritorno possibile:** Ripristino da Arca/Drive/RDX secondo copia verificata; mai cancellare unico originale.

## Gennaio 2027 · in parallelo alle copie — Vito: primo viaggio operativo

Lavorare e consultare documenti anche senza casa e LTE.

- Verificare monitor/touch e alimentazione con C1 reale
- Configurare rete di bordo e accesso ai soli servizi necessari
- Preparare rapportino offline con invio e conferma senza duplicati
- Provare sosta camper, rientro, copia dati e arresto con energia ridotta

**Si passa oltre quando:** Rapporto offline recuperato e registrato una sola volta; documenti consultabili senza rete.

**Ritorno possibile:** Kit documenti locale e procedura manuale; nessuna dipendenza da automazioni non collaudate.

## Gennaio-febbraio 2027 · dopo collaudi hardware — Domotica, media e telemetria

Attivare gli acceleratori soltanto dove servono.

- Installare Hailo e camere se acquistati, misurare decodifica e detector
- Provare Arc e rete su M6; abilitare transcodifica soltanto dopo test
- Collaudare HAOS/MQTT su C3 e app selezionate su C4
- Censire eventuali sensori Vito e verificare compatibilita diagnostica

**Si passa oltre quando:** Carichi reali stabili; failover e recuperi documentati; nessuna capacita presunta.

**Ritorno possibile:** Direct play/media preparati, Frigate ridotto, gestione manuale e copie precedenti.

## Febbraio-marzo 2027 · finestra adattabile — Ottimizzazione e chiusura

Consolidare soltanto cio che e stato misurato.

- Regolare RAM/ARC da metriche; verificare consumi idle e picchi
- Verificare stato backup, spazio Drive e selezioni RDX
- Collaudare perdita LTE del Vito e perdita WAN di casa
- Aggiornare registro installato, schede e lista acquisti residui

**Si passa oltre quando:** Registro collaudi completo e nessuna sorgente unica dimenticata.

**Ritorno possibile:** Mantenere configurazione precedente e copie di migrazione finche necessario.

## Banda e calendario realistico

A 4 Mbit/s un TB richiede circa 23,1 giorni teorici continui; a 20 Mbit/s circa 4,6; a 100 Mbit/s circa 0,93. Volumi, velocita e disponibilita reale sostituiscono queste stime. Non trattare la quota mobile casa da 500 GB come uplink illimitato.

Calendario locale Europe/Rome. Le checklist del sito sono appunti salvati nel browser, non prove di collaudo o aggiornamenti remoti. Nessun evento Calendar o task Vikunja e stato creato.

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "REV3-FAM"
titolo: "Recuperi, scambi e postazioni familiari"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# REV3-FAM · Recuperi, scambi e postazioni familiari

| Dispositivo | Situazione aggiornata | Effetto sulla 4.4 |
| --- | --- | --- |
| MP3 Acer Aspire 7 | Scambio approvato, Acer rientrato | Sempre fisso in laboratorio; Windows e lavoro/gioco |
| MP4 X99 Deluxe/i7-5930K/32 GB/2080 | PC previsto per il primo fratello | Assegnazione conservata; consegna effettiva non attestata |
| MP2 MacBook Air M1 8/256 | Scambio ancora in sospeso | Non richiesto per operativita laboratorio/Vito |
| MP5 kit X79 Extreme3/i7-3820 | Kit da testare, scenario secondo fratello | Condizionato allo scambio; non macchina funzionante presunta |
| Microtech EBL14B | Recuperato, nuova destinazione ingresso | Pannello citofono/allarme; batteria e audio/video da provare |
| Due HP t520 | Client pilota per due amici | Familiari gia serviti dai propri dispositivi sulla rete Sky |

Il MacBook personale resta MP1 e non viene riallocato. Il rientro dell'Acer non prova automaticamente una consegna del PC fisso. Gli assistenti non hanno disponibilita o quorum garantiti da uno scambio ancora in sospeso. Le dotazioni dell'Acer sono quelle dichiarate sull'esemplare, senza usare il datasheet di un suffisso diverso.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-OPEN]] · [[REV3-DIFF]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

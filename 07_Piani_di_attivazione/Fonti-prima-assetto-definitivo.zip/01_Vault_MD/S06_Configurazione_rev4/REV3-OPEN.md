---
codice: "REV3-OPEN"
titolo: "Dati da completare e gate tecnici"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# REV3-OPEN · Dati da completare e gate tecnici

| Ambito | Oggetto | Riscontro necessario |
| --- | --- | --- |
| Schede D1581 | Q3/Q3A | Due NVMe Q3A, bus slot, RAM RDIMM e avvio da collaudare sulle revisioni ricevute |
| M1 | Xeon v4 e PR9-H | SKU CPU, avvio senza GPU, IOMMU e passthrough NIC; 4 porte non implicano 4 linee indipendenti |
| RAM Vinted | 6 x16 GB PC3L | Offerta 85 EUR; non acquistata. Etichette, test memoria e canali |
| M6 | Arc + MNPA19-XTR | Spazi e linee simultanee, alimentazione e driver; Arc non acquistata |
| M5 | Hailo e camere | M-key/PCIe e decodifica da provare; entrambi ancora da acquistare |
| Dati | Volume totale e banda | 5 TB Drive liberi dichiarati; tutti i media inclusi nella transizione; misurare |
| RDX | Modello e tre cartucce HP | 2 TB per selezione e versioni; 150 EUR offerta riferita, non ordine |
| Cluster 5 | C3/C4 e repliche | 16 GB nominali e SSD da misurare; failover solo per guest che entrano |
| M4 | Media SMR | RAIDZ1 non ratificato senza prova; possibile mirror a coppie riduce spazio nominale a 4 TB |
| Vito | Identita e dotazione | Anno/motore/Euro, SSD C1, touchscreen, modem/SIM e accumulo da definire |
| Energia | Rack e veicolo separati | Assorbimenti e percorsi UPS/USB-C da misurare, nessuna autonomia garantita |
| Drive | Cifratura della transizione | Scelta utente ancora aperta; raccomandazione cifrare almeno dati privati/lavoro; cartelle da preparare separatamente |

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

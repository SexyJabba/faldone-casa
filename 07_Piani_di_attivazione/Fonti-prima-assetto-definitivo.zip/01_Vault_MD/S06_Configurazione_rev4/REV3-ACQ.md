---
codice: "REV3-ACQ"
titolo: "Acquisti, trattative e spesa evitata"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# REV3-ACQ · Acquisti, trattative e spesa evitata

| Voce | Quantita | Importo | Stato | Destinazione |
| --- | --- | --- | --- | --- |
| D1581-Q3A | 2 | 189.67 EUR | Acquisto dichiarato | M2 e M6, subordinati al collaudo |
| MACHINIST X99 PR9-H + CPU | 1 | 47.88 EUR | Acquisto dichiarato | M1 |
| Mellanox MCX312A-XCBT dual 10GbE | 1 | 32.99 EUR | Acquisto dichiarato | M2, link dedicati M3 e M4 |
| DAC passivi 10G, 1 m | 2 | 22.44 EUR | Acquisto dichiarato | Uplink M4/M6 verso switch: proposta |
| 6 x16 GB Hynix/HP PC3L-10600R RDIMM | 6 | 85.00 EUR | Offerta in attesa | 2 moduli M5, 4 M6; nessun modulo ancora arrivato |
| Cartucce HP RDX 2 TB | 3 | 150.00 EUR | Proposta da acquistare | Foto/video, documenti, lavoro: tre selezioni diverse |
| BKHD + E5-2630L v3 | 0 | Non conteggiato | Ordine annullato | Escluso dalla configurazione |
| Pool 8 SSD enterprise M2 | 0 | Non conteggiato | Rinviato | P310 4 TB come segnaposto |

I quattro ordini nello screenshot totalizzano 292,98 EUR, spedizioni comprese secondo l'utente. Stato screenshot: verifica del pagamento; acquisto dichiarato, consegna non attestata. I 85 EUR RAM sono offerta, non spesa conclusa. I 150 EUR RDX sono proposta per tre cartucce, non nuovo ordine. Non sommare il lotto Dell da 150 EUR gia acquistato come nuova spesa.

Q3 preesistente in arrivo; quattro PC3L gia posseduti; DDR4 M1 disponibile; P9D arrivata; RTX3060 montata su M3 secondo precedenti dichiarazioni. Z9PA e BKHD escono dagli acquisti attivi. Pool SSD M2 rinviato: vecchio preventivo 350-400 EUR, non un prezzo corrente garantito.

Restano da scegliere dopo collaudo: Arc A310, Hailo e camere, rete Wi-Fi/switch, energia rack e Vito, touchscreen e modem/SIM del mezzo. Riuso prima di acquisti; nessun ordine viene effettuato dal faldone.

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

# Configurazione 4.4 · configurazione 4.4

| Codice | Scheda | Revisione |
| --- | --- | --- |
| [[REV3-ACQ]] | Acquisti, trattative e spesa evitata | 4.4 |
| [[REV3-AGN]] | Assistenti e lavoro fra laboratorio e Vito | 4.4 |
| [[REV3-ATL]] | Architettura e apparati della revisione 4.4 | 4.4 |
| [[REV3-BCK]] | Backup: locale, fuori casa e selezioni offline | 4.4 |
| [[REV3-CLOUD]] | Drive: Arca temporanea e backup remoto | 4.4 |
| [[REV3-CLX]] | Cluster stabile: cinque voti, carichi a richiesta separati | 4.4 |
| [[REV3-DIFF]] | Cosa cambia dalla 4.3 | 4.4 |
| [[REV3-ENE]] | Energia: nucleo stabile e carichi attivati quando servono | 4.4 |
| [[REV3-EXT]] | Due HP: client esterni e visione offline | 4.4 |
| [[REV3-FAM]] | Recuperi, scambi e postazioni familiari | 4.4 |
| [[REV3-GST]] | Guasti, disponibilita e recupero | 4.4 |
| [[REV3-HA]] | Cluster stabile: cinque voti, carichi a richiesta separati | 4.4 |
| [[REV3-INV]] | Magazzino e componenti liberati | 4.4 |
| [[REV3-KDL]] | Kindle: biblioteca e plancia personale | 4.4 |
| [[REV3-MAP]] | Storage: transizione e destinazioni definitive | 4.4 |
| [[REV3-MOB]] | Vito: lavoro, camper e autonomia mobile | 4.4 |
| [[REV3-OPEN]] | Dati da completare e gate tecnici | 4.4 |
| [[REV3-RET]] | Rete: percorsi chiari per casa, servizi e Vito | 4.4 |
| [[REV3-SRC]] | Fonti e versioni | 4.4 |
| [[REV3-SRV]] | Servizi: collocazione e dipendenze | 4.4 |
| [[REV3-STATO]] | Disponibilita: cio che sappiamo al 1 novembre | 4.4 |
| [[REV3-STO]] | Storage: transizione e destinazioni definitive | 4.4 |
| [[REV3-TRN]] | Energia: nucleo stabile e carichi attivati quando servono | 4.4 |
| [[REV3-VIS]] | IA, visione e media: confini di calcolo | 4.4 |
| [[REV3-WRK]] | Voce, Sheets e agenda di lavoro | 4.4 |
| [[REV4-ENER]] | Energia: nucleo stabile e carichi attivati quando servono | 4.4 |
| [[REV4-HOME]] | Architettura e apparati della revisione 4.4 | 4.4 |
| [[REV4-MIG]] | Transizione: copie prima, nuovi pool dopo | 4.4 |
| [[REV4-MON]] | Osservabilita: capire prima di intervenire | 4.4 |
| [[REV4-PCIE]] | Espansioni e verifiche delle schede ricevute | 4.4 |
| [[REV4-RAM]] | Memorie: disponibilita, distribuzione e utilizzo | 4.4 |
| [[REV4-ROAD]] | Roadmap: da Natale 2026 alla configurazione collaudata | 4.4 |
| [[REV4-TEST]] | Collaudi e registro di accettazione | 4.4 |
| [[REV4-VCAMP]] | Camper: servizi locali e modalità di sosta | 4.4 |
| [[REV4-VDIAG]] | Diagnostica W639: telemetria e strumenti Mercedes | 4.4 |
| [[REV4-VENE]] | Energia di bordo: alimentazione, carichi e riserva | 4.4 |
| [[REV4-VITO]] | Vito: il nodo mobile tra lavoro e camper | 4.4 |
| [[REV4-VLAV]] | Lavoro a bordo: dal cantiere al registro | 4.4 |
| [[REV4-VNET]] | Rete mobile: bordo, casa e cloud | 4.4 |
| [[REV4-VSYNC]] | Dati mobili: preparazione, sincronizzazione e recupero | 4.4 |
| [[REV4-VTEST]] | Vito: roadmap di attivazione e prove di accettazione | 4.4 |

[[START]] · [[CATALOGO]]

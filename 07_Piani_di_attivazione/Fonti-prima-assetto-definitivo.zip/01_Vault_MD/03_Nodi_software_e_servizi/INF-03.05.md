---
codice: "INF-03.05"
titolo: "M6: media, servizi esterni e margine di calcolo"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-03.05 · M6: media, servizi esterni e margine di calcolo

M6 usa la seconda D1581-Q3A, con 64 GB PC3L dal lotto Vinted ancora in trattativa. La Z9PA-U8 esce dalla lista acquisti; il vecchio E5-2630L v2 non viene conteggiato come CPU della nuova scheda. M6 e Proxmox autonomo, fuori dai voti del nucleo stabile, acceso su richiesta o durante download e lavoro autorizzato.

Arc A310 rimane candidata, non acquistata. Prima verificare GPU e MNPA19-XTR simultanee: slot, linee, ingombri, BIOS e driver. Se manca questa possibilita, avvio con rete integrata e direct play/media preparati; non comprare un adattatore presumendo biforcazione. L'assenza di ReBAR non prova da sola che ogni transcodifica sia impossibile: si collauda il percorso reale.

Separare cloud Seafile, Jellyfin/audio e download/arr in ambienti con account, mount e limiti distinti. Preferire LXC non privilegiati dove supportati; non promettere isolamento da VM per container che condividono kernel. Nessun downloader nella rete fidata generale.

V300 120 GB per boot; EVO 500 GB per staging e spazio SSD quotato di DB; due WD10EZRX da 1 TB in mirror per Seafile e audio locale. Dieci utenti per 50 GB significa 500 GB, con margine separato per versioni/audio. Seafile esterno mantiene la scelta gia esplicita: niente backup aggiuntivo automatico dei contenuti su M4 o Drive. Il caricamento totale della transizione va riconciliato per eventuali dati di terzi prima di includerli.

La RAM aggiuntiva puo sostenere servizi e cache del pool locale. I film archiviati su M4 non beneficiano automaticamente dell'ARC di M6. Temporanei di transcodifica in RAM solo con quote e dati ricreabili. Avviare M4 quando il file richiesto e remoto, attendere readiness e non spegnerlo durante una visione. Nessun timer M6 imposto senza osservazione. [[REV4-RAM]] · [[REV4-MON]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "INF-03.03"
titolo: "M2: applicazioni e P310 provvisorio"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-03.03 · M2: applicazioni e P310 provvisorio

M2 viene assegnato alla D1581-Q3A per utilizzare due M.2, subordinatamente a prova NVMe simultanea e compatibilita della revisione. I quattro banchi PC3L da 16 GB gia posseduti danno 64 GB. Sabrent Rocket 512 GB per avvio; Crucial P310 4 TB come storage dati provvisorio, recuperato da Arca soltanto dopo copia e recupero verificati.

Il P310 e un segnaposto finche il futuro pool SSD avra senso economico. Rinviati otto SSD enterprise e relativi cavi; la LSI9207-8i resta disponibile e non e necessaria alla fase NVMe. Nessun nuovo prezzo futuro garantito. Un filesystem ZFS su singolo SSD offre controlli e snapshot ma non ridondanza: al guasto serve sostituzione e ripristino.

M2 ospita Nextcloud, Vikunja, n8n, Immich, Paperless, Syncthing, SMB/NFS e applicazioni personali censite. Stato e database hanno backup coerenti. I modelli pesanti e i lotti differibili vanno a M3 su richiesta, non sul firewall; Paperless mantiene OCR supportato. Nessun Coral in acquisto: non accelera automaticamente Tesseract o LLM.

M2 resta normalmente acceso nel nucleo stabile. C4 e riserva delle sole applicazioni selezionate con guest, DB e dati completi entro spazio/RAM verificati: i 4 TB non migrano automaticamente su un piccolo SSD Dell. Gli altri servizi attendono il ripristino. La replica non sostituisce WD, Drive e RDX.

MCX312A dual-port: link dedicati A verso M3 e B verso M4, senza gateway e senza ponte generale fra reti. Gestione su percorso separato. Non spostare i dati sul P310 prima che Arca sia liberabile. [[REV4-MIG]] · [[REV3-BCK]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

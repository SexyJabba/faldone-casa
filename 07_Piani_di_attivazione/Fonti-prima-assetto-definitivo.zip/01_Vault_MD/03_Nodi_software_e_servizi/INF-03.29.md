---
codice: "INF-03.29"
titolo: "M5: domotica e visione locale"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-03.29 · M5: domotica e visione locale

M5 usa la D1581-Q3 in arrivo, se il bus permette Hailo M-key con avvio SATA. La BKHD e esclusa: ordine annullato, non in consegna. Memoria obiettivo 32 GB PC3L RDIMM, due moduli del lotto Vinted ancora da acquistare. La DDR4 precedentemente destinata a M5 va a M1.

Proxmox nel nucleo stabile ospita HAOS, broker MQTT separato e ambiente Frigate/go2rtc/vision-gateway. Samsung 850 EVO 250 GB per boot/stato; due ST1000LM024 da 1 TB in mirror per registrazioni, circa 1 TB nominale. Quattro camere iniziali e sette giorni di eventi sono obiettivi da misurare; sei camere sono espansione. Hailo e camere restano da acquistare.

Hailo esegue inferenza compatibile, non decodifica video e non esegue LLM generici. Substream H.264 leggeri e decodifica CPU sono la base da collaudare. Frigate ha priorita; nessun doppio passthrough esclusivo a due VM. Condividere runtime solo se supportato dalla versione effettiva.

Sonoff/Zigbee2MQTT resta su S3. Reti IoT e AP non attraversano fisicamente M5 come unico ponte. La Q3 non eredita le sei porte della BKHD: interfacce e percorso avvisi via router 5G vanno mappati e isolati.

C3 e riserva per HAOS e MQTT dopo test di replica completa, fencing e capacita. Frigate, Hailo e registrazioni non diventano HA. Un guasto non richiede di trasferire la radio USB da S3. [[REV3-HA]] · [[REV4-PCIE]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

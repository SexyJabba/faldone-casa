---
codice: "INF-03.21"
titolo: "Download e arr isolati su M6"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-03.21 · Download e arr isolati su M6

M6 usa la seconda D1581-Q3A, con 64 GB PC3L dal lotto Vinted ancora in trattativa. La Z9PA-U8 esce dalla lista acquisti; il vecchio E5-2630L v2 non viene conteggiato come CPU della nuova scheda. M6 e Proxmox autonomo, fuori dai voti del nucleo stabile, acceso su richiesta o durante download e lavoro autorizzato. Vedere [[INF-03.46]].

Il mount M4 assente sospende gli import; non scrivere nella directorylocale rimasta vuota al posto del mount. Accountarrscrittura distinto da Jellyfin RO e da Seafile. Le analisi/scansioni sono limitate e nessun automatismo extraarr viene aggiunto. Se M4 spento download/seedinglocali possono continuare finche c’e spazio.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-MAP]] · [[REV3-OPEN]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

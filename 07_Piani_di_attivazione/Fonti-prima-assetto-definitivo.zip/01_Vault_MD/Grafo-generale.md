# Domini della 4.4

Nucleo stabile: M1/M2/M5/C3/C4, cinque voti e quorum tre. M3/M4/M6 autonomi a richiesta. S4 sentinella senza voto. Vito autonomo e fuori cluster. [[REV3-HA]] · [[REV4-VITO]]

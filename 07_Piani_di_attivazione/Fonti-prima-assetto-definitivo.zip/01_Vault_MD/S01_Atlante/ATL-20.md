---
codice: "ATL-20"
titolo: "Rete: percorsi chiari per casa, servizi e Vito"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# ATL-20 · Rete: percorsi chiari per casa, servizi e Vito

| Origine | Percorso | Destinazione | Vincolo |
| --- | --- | --- | --- |
| FTTC | WAN1 | M1 / firewall | Upload4Mbit/s; ordinario/download file con limite dinamico |
| Router5G esterno / LAN1 | WAN2 | M1 | SIM ho.casa500 GB, servizi remoti personali ed esterni |
| Router5G esterno / LAN2 | Avvisi indipendenti | M5 | Percorso notifiche anche con M1 fermo; nessun ponte libero |
| M1 I226-T4 | Fidata / DMZ personale / esterna | Switch e reti autorizzate | Porte/trunk da mappa definitiva; doppia WAN non assume quinta porta |
| Switch/AP IoT | VLAN locale/cloud/camere | M5 / S3 / C3 autorizzati | Rete e AP non transitano solo da M5 |
| M2 MCX312A / SFP+1 | 10Gb E A | M3 MNPA19-XTR | Link dedicato senza gateway |
| M2 MCX312A / SFP+2 | 10Gb E B | M4 SFP+1 | Link dedicato senza gateway |
| M4 SFP+2 | 10Gb E uplink | Switch fidato | Distinto dal link B; gestione e accessi autorizzati |
| M2 2, 5Gb E | Gestione e servizi | Switch / DMZ personale | Gestione esclusa dalla pubblicazione; interfacce da mappare |
| M5 interfacce da riscontro | Gestione/servizi e percorsi IoT | Switch/router5G | Nessuna eredita delle sei porte BKHD; percorso avvisi 5G da collaudare e segmentare |
| C3 / C4 Ethernet | Cluster e repliche | Switch fidato | Wi-Fi non bridge automatico per VM; client Linux locale separato |
| S3 / Sonoff USB | Zigbee | Dispositivi compatibili | Z2M verso broker M5/C3; binding diretto dove supportato |
| S4 Ethernet | Sentinella e WoL | Nucleo stabile e nodi autonomi | Nessun qdevice nella base a cinque voti |
| 3 Halo H1900G | Wi-Fi casa attuale -> IoT a regime | Appartamento e laboratorio PT | Liberati solo dopo sostituzione Wi-Fi casa |
| Nuovo Wi-Fi casa | 4piani + esterno | Punti Ethernet e uplink wireless | Budget150 EUR complessivo; AP mesh/VLAN/revisioni da offerte |
| M6 MNPA19-XTR | 10GbE uplink D | Switch fidato SFP+2 | Kit gia ordinato; DAC 1 m acquistati dichiarati, lunghezza/codifica da verificare |
| Vito LTE | Rete veicolo autonoma | C1 e servizi di bordo | Modem/SIM dedicati, nessun voto Corosync |
| Due HP esterni | Ethernet DHCP | Jellyfin via HTTPS | Identita individuali; mai ponte verso LAN fidata |

Gestione/Corosync cablati restano locali e disponibili con OPNsense fermo. M3/M4/M6 hanno gestione propria fuori cluster; i link 10GbE dedicati non diventano gateway generali o ponte tra DMZ. Due AOC da 3 m gia ordinati e due DAC da 1 m nuovi si assegnano dopo misura lunghezze, non per numero di porte.

Le reti famiglia, IoT, camere, servizi esterni e gestione hanno permessi espliciti. VLAN, subnet e nomi OS sono campi da compilare prima dell'attivazione, non valori inventati. La SIM casa non e automaticamente quella del Vito. Il veicolo usa rete autonoma e accesso autenticato selettivo, senza bridge libero nella LAN domestica. [[REV4-VNET]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

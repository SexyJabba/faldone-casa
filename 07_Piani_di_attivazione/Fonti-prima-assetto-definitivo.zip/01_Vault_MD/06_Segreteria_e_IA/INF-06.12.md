---
codice: "INF-06.12"
titolo: "M3: inferenza dedicata e calcolo a richiesta"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-06.12 · M3: inferenza dedicata e calcolo a richiesta

M3 conserva X99-T8 / E5-2678 v3,128 GB DDR3 RDIMM e Proxmox, dedicati all’IA. GPU MSI RTX3060 Ventus 2X 12 GB; WD PC SN530512 GB nello slot M.2PCIe2.0 per host e IA. Windows e Hermes sono su MP3 Aspire; RTX2080 segue MP4, PC del primo fratello. L’altro M.2 non e riservato alla vecchia VM Windows; il saldo Samsung NVMe e ancora da associare. A380 o RTX30506 GB sono espansioni integrative non acquistate.

Priorita: richieste personali interattive, poi agenti, infine fondo. La priorita si applica attraverso un arbitraggio comune ai lavori in attesa; non promette interruzione immediata della generazione in corso o concorrenza nella VRAM. Modelli, contesto e motore si scelgono sull’hardware. L’Hailo e un detector su M5, non un acceleratore LLM di M3.

Se M3 e spento l’utente sceglie «accendi adesso» con conferma oppure «metti in coda» fino a un’altra accensione e all’endpoint pronto. Il recupero quorum ha una politica distinta. Dopo30 min senza lavori IA attivi o autorizzati in attesa, arresto ordinato solo se nessun servizio/operazione richiede il nodo e il quorum residuo e garantito. Un modello caricato ma inattivo non e un lavoro attivo. Cloud solo su richiesta/conferma, nessun job periodico e nessuna API a consumo.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-MAP]] · [[REV3-OPEN]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

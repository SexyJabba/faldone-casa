---
codice: "INF-06.02"
titolo: "Assistenti sui portatili"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-06.02 · Assistenti sui portatili

L'Acer Aspire 7 MP3 e la postazione Windows sempre fissa in laboratorio. La dotazione dichiarata e Ryzen 7 5700U, RTX 3050 Ti 4 GB, 16 GB RAM e Crucial P3 Plus 1 TB. Windows ospita lavoro, Steam/retrogaming e Sunshine, con utenti e permessi distinti per lavoro/assistente e gioco. Il cambio utente non chiude automaticamente l'altra sessione: i carichi agenti si riducono durante il gioco.

OpenClaw di lavoro ha nell'Acer il riferimento aggiornato; Hermes mantiene l'Acer come sede prevista. Gli ambienti effettivi, la convivenza e il runtime compatibile con Windows si verificano in configurazione: non sono attestati due agenti gia installati ne un isolamento forte dato dal solo account. Il modello leggero locale e l'inferenza principale M3 restano distinti. La GPU da 4 GB e condivisa con grafica e gioco.

Il MacBook Air M1 MP2, 8/256, appartiene a uno scambio ancora in sospeso. Non e la postazione necessaria di laboratorio della 4.4 e non viene contato come ricevuto. Il MacBook personale MP1 resta distinto. L'eventuale Mac mini M1 sotto 200 EUR o upgrade Dell 32 GB sotto 100 EUR restano scenari storici condizionati, non acquisti prescritti.

M3 resta dedicato all'IA: se spento, l'agente propone accensione immediata su conferma oppure coda fino a successiva disponibilita. Priorita richieste personali, agenti, lavori di fondo. Niente inferenza principale continua obbligatoria per mantenere gli agenti operativi.

Nel Vito il lavoro usa anche Gemini e Google AI Pro sull'account di lavoro, con Sheets condivisi e Calendar; una sessione avviata dall'utente e distinta da un processo autonomo a consumo. L'abbonamento non e un credito API automaticamente disponibile a OpenClaw. Cloud su richiesta/conferma, senza job periodici pagati impliciti. Le informazioni operative persistono nei registri condivisi, non nella sola chat.

[[REV3-MOB]] dettaglia il PC del Vito; [[REV3-WRK]] il flusso di lavoro Google. Gli agenti e le postazioni mobili rimangono fuori quorum.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-OPEN]] · [[REV3-DIFF]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

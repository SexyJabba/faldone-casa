---
codice: "INF-11.04"
titolo: "Tagliando rete, nodi autonomi e accessi"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-11.04 · Tagliando rete, nodi autonomi e accessi

## Rami, gestione e storage

La mesh/rete familiare accede al router del provider indipendentemente da M1. M1 serve la rete privata: il suo guasto può togliere DHCP/DNS/routing ai segmenti privati, non automaticamente Internet a tutta la famiglia. Preservare il Netgear GS305E disponibile.

**Collegamenti storage.** MCX312A M2:porta1 verso MNPA19 M3, porta2 verso SFP+1 M4; SFP+2 M4 allo switch. Tre link distinti10Gb E. Rete gestione/cluster separata dai linkdiretti senza gateway, disponibile anche con M4 spento. Windows su MP3 Aspire usa il proprio percorso LAN.

## Segmentazione e accesso

**Confini fisici.** M2 servizi personali e M6 servizi esterni hanno accessi distinti; Hermes MP3 e OpenClaw MP2 sono personali. M4 interno:media RO a Jellyfin e scritturaarr limitata, repository WD esclusi. Reti IoTlocale/cloud/camere su switch/AP indipendenti da M5. Vedi REV3-RET.

I percorsi diretti ai nodi non richiedono Caddy, dashboard o M2. Verificare DNS quando M1/HP sono assenti e registrare indirizzi di recupero fuori dal vault online. Il profilo di accesso remoto identifica nodo, account e autenticazione nel registro del servizio.

## Energia

**Alimentazione e disponibilita.** M3 IA e M4 media/backup hanno arresto30 min con controllo quorum residuo; M6 su richiesta senza timerstop fissato. Backup M4 giornaliero18:00. Rack power station diretta UPS, client compatti per stop e cluster arrestabile nei blackout prolungati. Vedi REV3-ENE.

**S1-S4.** Q1900S1utilita; Oracle S2 osservazione esterna; Wyse S3 radio/Z2M; Wyse S4 sentinella indipendente (senza voto) e primo WoL. C4 secondo WoL. HP destinati ai due amici esterni. Vaultwarden escluso da S2.

S1 fornisce accesso e utilita senza dipendere da quorum o QDevice; S2 osserva dall'esterno. Accesso diretto a router, hypervisor, NAS e HA documentato fuori dal reverse proxy, con credenziali recuperabili anche a S1 spento. NUT richiede UPS e collegamento supportati effettivamente disponibili, non solo il software.

## Esiti da compilare

Data: __________ Responsabile: __________ Evidenza/log: __________ Esito: __________ Residui: __________

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

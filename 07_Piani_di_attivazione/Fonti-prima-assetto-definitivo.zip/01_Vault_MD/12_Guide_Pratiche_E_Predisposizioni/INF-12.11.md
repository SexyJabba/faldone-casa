---
codice: "INF-12.11"
titolo: "Client Linux: profili d’uso"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-12.11 · Client Linux: profili d’uso

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

**Windows - M3.** Una VM Windows con RTX2080 dedicata ospita due account alternativi: Lavoro durante il giorno e Gioco/Steam la sera. Sunshine funziona come servizio; i client usano Moonlight e condividono una sola sessione desktop interattiva. Cambio utente e disconnessione appartengono alla sessione Windows; più client non creano desktop indipendenti. In studio video e USB raggiungono direttamente la postazione. La console Proxmox non sostituisce l’uscita video della GPU in passthrough.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "INF-05.05"
titolo: "Profilo A: PC e thin client"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.05 · Profilo A: PC e thin client

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

| OS del client | Vantaggi / verifiche |
| --- | --- |
| Windows | Moonlight, browser, app e software USB generalisti. Verificare licenza, supporto dell’OS, driver del decoder e avvio automatico. |
| Linux | Buono per riciclo e avvio dedicato a Moonlight; server USB possibile. Decoder, audio, sospensione e HDR dipendono dalla distribuzione e dalla build. |
| macOS | Riutilizza un Mac esistente; Moonlight, app personali e server USB disponibile. Risoluzioni esterne, dock e modalità input dipendenti dal modello. |

## Identikit d’acquisto

• Ethernet Gigabit, uscita video adeguata, almeno due USB utili o hub alimentato; Wi-Fi/Bluetooth se necessari alla stanza. Consumo e rumore vanno verificati sul modello reale.

• Decodifica H.264 hardware stabile. Per 4K/HDR verificare HEVC Main10 nella documentazione e nel driver; “Intel vecchio” o “GPU integrata” non è una specifica sufficiente.

• Per uso misto desktop/browser: riferimento 8 GB RAM e SSD almeno 64 GB. Preferire hardware con OS ancora supportato; molte CPU Intel di settima generazione non rientrano nel supporto standard Windows 11. [RIF-CL-11]

## Assetto operativo consigliato

<b>01.</b> Account locale del client per l’uso quotidiano; aggiornamenti e rete configurati. Browser con homepage M2 e collegamenti ai servizi autorizzati.

<b>02.</b> Moonlight in evidenza; coppia con Sunshine e profilo video della stanza. Mouse/tastiera e controller associati localmente.

<b>03.</b> Server USB avviato automaticamente solo dove necessario. Disattivare sospensioni indesiderate durante uno stream e provare il riavvio del client.

| <b>Quando sceglierlo</b><br/>Scrivania, lavoro su Windows, periferiche particolari e schermi con più ingressi. Un thin client usato è adatto se decoder e porte rispettano il profilo; il suo marchio non garantisce HEVC o 4K60. |
| --- |

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

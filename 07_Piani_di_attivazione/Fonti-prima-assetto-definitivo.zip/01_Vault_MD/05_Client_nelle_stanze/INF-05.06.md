---
codice: "INF-05.06"
titolo: "Profilo B: Android TV e box Android"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.06 · Profilo B: Android TV e box Android

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

Android TV / Google TV con telecomando offre un’interfaccia da salotto. Un box con Android generico può avere launcher da tablet, aggiornamenti incerti e limitazioni delle app in abbonamento. Certificazione per servizi video e capacità Moonlight sono controlli separati.

| Criterio | Controllo prima della scelta |
| --- | --- |
| Moonlight | App Android installabile, decoder hardware a bassa latenza, corretta gestione controller e puntatore. [RIF-CL-03-RIF-CL-04] |
| Media locali | App Jellyfin Android TV o Kodi; verificare formati audio, sottotitoli e riproduzione diretta. [RIF-CL-14-RIF-CL-15] |
| Netflix / Prime e simili | App ufficiali, certificazione del modello e qualità realmente consentita. I plugin Kodi non sono una garanzia di supporto. |
| USB over IP | Porta USB host o adattatore compatibile, alimentazione adeguata e VirtualHere Android installabile. [RIF-CL-20] |
| Rete e video | Gigabit preferibile per 4K; verificare HDMI effettivo, HDR, Wi-Fi e stabilità sotto carico. |

## Esempi hardware di riferimento

<b>NVIDIA Shield TV Pro:</b> Gigabit, due USB-A 3.0, uscita HDMI 2.0b e media fino a 4K60: dotazione favorevole per ingressi locali. <b>Google TV Streamer:</b> Gigabit, HDMI 2.1 e 4K60; USB-C dichiarata per alimentazione/dati, del profilo operativo con hub e alimentazione per la periferica concreta. Questi sono esempi di caratteristiche, non acquisti decisi. [RIF-CL-24-RIF-CL-25]

## Configurazione stanza

• Tenere app native e Moonlight sulla schermata iniziale. Telecomando per scegliere; gamepad per giocare; tastiera/puntatore per Windows.

• Provare CEC, accensione TV, uscita audio e rientro alla home. L’avvio della VM resta un’operazione in sala server.

• Se USB e alimentazione condividono un adattatore, provare anche lo scenario con tutte le periferiche collegate.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

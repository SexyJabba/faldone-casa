---
codice: "INF-05.10"
titolo: "Altri endpoint e riuso del materiale"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.10 · Altri endpoint e riuso del materiale

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

| Dispositivo | Ruolo utile / limite |
| --- | --- |
| Raspberry Pi / SBC Linux | Moonlight e ponte USB, se build, decoder e driver sono compatibili. Su Raspberry Pi 4 il percorso HEVC richiede attenzione alla modalità di esecuzione. Non è una box pronta senza configurazione. [RIF-CL-05-RIF-CL-06] |
| Chromebook | Client Moonlight tramite ambiente supportato/Android quando disponibile, browser e servizi web. Verificare restrizioni del modello, input e gestione USB. [RIF-CL-03] |
| Steam Deck / portatile gaming | Riutilizzo come Moonlight e client Linux; dock per TV, tastiera e USB. Può anche giocare localmente: non richiede una seconda postazione Windows. |
| PC vecchio / Mac mini esistente | Riuso se il decoder regge il profilo. Verificare OS supportato, porte e rumore/consumo. Potenza CPU alta non compensa sempre un decoder incompatibile. |
| Console / dispositivi modificati | Port comunitari sperimentali; richiedono verifica specifica. Non sono il percorso standard per client familiari. [RIF-CL-03] |
| Display cucina / piccoli pannelli | Browser per ricette, HA, musica e controlli; per Moonlight servono un sistema installabile e un decoder adatto. Un display passivo richiede un endpoint esterno. |

## Scelta per funzione, non per etichetta

Per un ponte USB può bastare un piccolo Linux cablato; per una TV 4K serve un decoder e un’uscita migliori; per lo studio contano input e porte. Il dispositivo che mostra il video e quello che esporta USB possono essere due macchine nella stessa stanza.

| <b>Esperimenti sensati</b><br/>Postazione mobile su dock, angolo retrogaming con controller, pannello per dashboard e telecamere, tablet per manutenzione. Registrare il ruolo e i parametri della postazione: non trasformare un esperimento in un servizio garantito per tutti. |
| --- |

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

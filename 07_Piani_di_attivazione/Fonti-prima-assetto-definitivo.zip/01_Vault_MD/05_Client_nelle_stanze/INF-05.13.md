---
codice: "INF-05.13"
titolo: "Uso simultaneo e musica da remoto"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.13 · Uso simultaneo e musica da remoto

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

**Perimetro:** Una Windows condivisa; media indipendenti

L’uso prevalente è una persona che cambia stanza. Sono assegnate anche persone diverse: una può giocare su M2 mentre un’altra vede Jellyfin o ascolta musica da M2. Il progetto offre una sola postazione Windows condivisa; sessioni indipendenti non sono assegnate.

Moonlight accede alla stessa postazione Windows. Due client non producono automaticamente due desktop o due giochi separati. Eventuali sessioni simultanee richiedono un progetto distinto.

REAPER e Ableton remoti servono per aprire, ascoltare e ritoccare progetti semplici. Registrazione, strumenti dal vivo e lavoro realmente in tempo reale restano sul Mac Book. La scheda audio locale può essere uscita del Dell: per il solo ascolto non è necessario importarla via USB over IP nella VM.

Compatibilità dei progetti e plugin Mac/Windows e percorso di cattura dell’audio vanno provati al livello applicativo, senza trasformarli in un obbligo di Windows locale sui client.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "INF-05.02"
titolo: "Identikit del client"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.02 · Identikit del client

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

| Uso | Profilo consigliato del profilo operativo |
| --- | --- |
| Desktop e giochi 1080p60 | Decodifica hardware H.264; HEVC utile. Rete Ethernet preferibile; tastiera/mouse o controller. |
| 1440p60 / TV 4K60 | HEVC hardware, uscita reale alla risoluzione scelta e decoder a bassa latenza. Gigabit consigliata. |
| HDR 4K60 | HEVC Main10, uscita HDR, display HDR10 e percorso host/client compatibile. Compatibilità dell’intero percorso. |
| 120 Hz | Uscita e display capaci dei 120 Hz alla risoluzione voluta; decoder, rete e host adeguati. Profilo opzionale, non requisito iniziale. |

## Dotazione minima utile della postazione

• Un’app Moonlight disponibile per l’OS; un browser aggiornato; app native per i servizi realmente utilizzati. Una pagina web generica non sostituisce il client Moonlight. [RIF-CL-03-RIF-CL-06]

• Un collegamento di rete stabile, alimentazione adeguata, uscita video compatibile e un percorso audio verificato. Per TV con Ethernet a 100 Mb/s verificare il margine al bitrate scelto.

• Almeno un modo pratico di selezionare le app e chiudere lo stream. Per Windows personale servono tastiera e puntatore; il telecomando da solo è scomodo.

• USB host locale o un ponte dedicato se la stanza deve esportare periferiche. Bluetooth locale è sufficiente per gli ingressi che Moonlight gestisce già.

| <b>Specifiche consigliate, non minimi ufficiali</b><br/>Per un mini PC generalista: 8 GB RAM e SSD da almeno 64 GB offrono margine per OS, browser e aggiornamenti. Una TV box non si valuta con gli stessi numeri: contano decoder, firmware, certificazioni, porte e prestazioni effettive. La GPU del client non deve eseguire il gioco. |
| --- |

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

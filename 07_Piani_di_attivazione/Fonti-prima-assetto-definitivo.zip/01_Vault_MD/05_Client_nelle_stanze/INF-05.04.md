---
codice: "INF-05.04"
titolo: "USB e periferiche della postazione"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.04 · USB e periferiche della postazione

**Windows - M3.** Una VM Windows con RTX2080 dedicata ospita due account alternativi: Lavoro durante il giorno e Gioco/Steam la sera. Sunshine funziona come servizio; i client usano Moonlight e condividono una sola sessione desktop interattiva. Cambio utente e disconnessione appartengono alla sessione Windows; più client non creano desktop indipendenti. In studio video e USB raggiungono direttamente la postazione. La console Proxmox non sostituisce l’uscita video della GPU in passthrough.

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

Video e periferiche sono percorsi distinti. USB over IP è una modalità per gli endpoint compatibili: tastiera, mouse, controller, webcam e audio non hanno gli stessi requisiti di banda e latenza. Il servizio è limitato alla LAN autorizzata e non pubblicato liberamente.

Il passthrough USB assegna il dispositivo al guest che lo usa; i conflitti fra host e VM sono gestiti per periferica. Per lo studio il percorso diretto conserva la relazione fra uscita video RTX2080 e sessione Windows. Le periferiche indispensabili all’accesso locale di recupero rimangono disponibili in sala server.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

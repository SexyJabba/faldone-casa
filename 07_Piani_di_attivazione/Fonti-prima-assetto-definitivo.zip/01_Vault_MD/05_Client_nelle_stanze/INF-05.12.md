---
codice: "INF-05.12"
titolo: "Servizi locali dei client"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.12 · Servizi locali dei client

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

Browser, player, Home Assistant e servizi multimediali usano i rispettivi account. Le funzioni locali del client non dipendono dalla sessione Windows. Segnalibri e collegamenti diretti consentono accesso ai servizi anche quando la dashboard o il reverse proxy sono indisponibili.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

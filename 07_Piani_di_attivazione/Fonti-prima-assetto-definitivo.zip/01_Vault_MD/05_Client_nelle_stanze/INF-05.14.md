---
codice: "INF-05.14"
titolo: "Uso quotidiano e diagnosi"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-05.14 · Uso quotidiano e diagnosi

**Postazioni e client.** Quattro Dell OptiPlex 7070 Ultra: uno in laboratorio per OpenClaw e lavoro, tre in cucina, camera e salone. Dotazione di riferimento i5-8265U, 8 GB e SSD256; Service Tag e componenti sono registrati per esemplare. Cucina e salone usano Debian KDE, camera Mint Xfce; il laboratorio usa Linux con browser di lavoro. I client mantengono browser, player e accesso HA locali; Moonlight raggiunge Windows su MP3 Aspire. Lo studio usa direttamente la VM Windows, senza un Dell riservato.

## Profilo e procedura di stanza

## Routine della postazione

Per i servizi locali aprire l’app. Per Windows verificare disponibilità di M3 e della VM, poi aprire Moonlight. Collegare le periferiche necessarie; acquisire solo l’USB speciale. A fine uso espellere i dischi, rilasciare l’USB e chiudere lo stream; lo spegnimento di Windows è una scelta separata.

| Sintomo | Controllo / azione |
| --- | --- |
| Homepage non apre | Verificare rete e DNS; provare l’indirizzo diretto. Se manca solo il nome, correggere DNS senza modificare il servizio. |
| Chat aperta, IA non risponde | Controllare M3 e backend del modello, poi rete e interfaccia M2. La pagina disponibile non prova il calcolo disponibile. |
| Moonlight non trova Windows | Verificare boot VM, Sunshine e firewall TCP/UDP; aggiungere indirizzo manualmente tra segmenti. |
| Schermo nero | Provare Desktop non protetto; controllare display, cattura e GPU. Se riguarda solo Sky/OTT può dipendere da protezione del contenuto. |
| Scatti / ritardo | Leggere statistiche; distinguere rete, decoder e host. Ridurre profilo, provare Ethernet, controllare carico IA/CPU. |
| Controller doppio / USB assente | Verificare inoltro Moonlight, proprietario USB e driver Windows. Evitare doppio percorso per lo stesso controller. |
| Film ricodificato / audio errato | Controllare formato, sottotitoli, client e capacità audio. Provare app nativa e file compatibile prima di cambiare server. |
| USB non si riprende | Rilasciare nel client USB, verificare server stanza/rete, riacquisire. Prima di scollegare storage espellere in Windows. |

Annotare sintomo, stanza, ora, profilo e variazione che ha risolto. Per guasti preboot o accesso fisico alla macchina usare la sala server come stabilito. Non trattare un riavvio generale come prima diagnosi di ogni problema.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

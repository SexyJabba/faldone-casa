# Faldone 4.4 | Casa, laboratorio e Vito

Configurazione di progetto del 1 novembre 2026. Attivazione dalle vacanze di Natale 2026, con gate di collaudo e copie verificate. Nessuna installazione dedotta dal documento.

- [[REV4-HOME]] Architettura
- [[REV4-VITO]] Nodo mobile
- [[REV4-ROAD]] Roadmap
- [[REV4-MIG]] Transizione dati
- [[REV4-RAM]] Memorie e cache
- [[REV4-MON]] Monitoraggio
- [[REV3-STATO]] Disponibilita
- [[REV3-DIFF]] Novita

- [[Indice-00]] Orientamento
- [[Indice-01]] Architettura e inventario
- [[Indice-02]] Rete e accessi
- [[Indice-03]] Nodi, software e servizi
- [[Indice-04]] Dati e recupero
- [[Indice-05]] Client nelle stanze
- [[Indice-06]] Agents, lavoro e inferenza
- [[Indice-07]] Casa e sicurezza
- [[Indice-08]] Esercizio e manutenzione
- [[Indice-S01]] Atlante
- [[Indice-S02]] Registri e fonti
- [[Indice-S03]] Tagliandi e registri di manutenzione
- [[Indice-S04]] Uso, accesso e recupero
- [[Indice-S05]] Modelli di collaborazione fra sedi
- [[Indice-S06]] Configurazione 4.4
- [[Indice-T01]] Profili operativi
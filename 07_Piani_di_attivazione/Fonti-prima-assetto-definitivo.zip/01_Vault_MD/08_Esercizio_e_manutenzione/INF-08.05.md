---
codice: "INF-08.05"
titolo: "M1: rete, monitoraggio e recupero"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-08.05 · M1: rete, monitoraggio e recupero

M1 usa MACHINIST X99 PR9-H con Xeon v4 dichiarato dall'utente; il modello esatto della CPU resta da etichetta. La variante acquistata comprende scheda e CPU; non viene inventata RAM inclusa. I 32 GB DDR4 ECC RDIMM disponibili sono trasferiti al ruolo M1. Proxmox ospita OPNsense e una VM separata di monitoraggio.

La I226-T4 occupa lo slot lungo. Verificare avvio senza GPU, gruppi IOMMU, reset e passthrough; console temporanea con materiale disponibile, poi gestione remota e accesso di emergenza. Il manuale PR9-H indica un PCIe x16 e un x1: non promettere GPU e NIC ad alta banda simultanee. Quattro porte fisiche non diventano cinque per la presenza di due WAN e piu VLAN.

OPNsense parte con 8 GB; la VM Zabbix con 2 vCPU e 4-8 GB, limiti I/O e conservazione metriche/log misurata sul boot da 120 GB. Servizi ausiliari non devono bloccare il routing. Nessuna dipendenza di avvio di rete da un database di monitoraggio.

M1 e nel nucleo stabile a cinque voti. Il firewall ha un percorso di recupero manuale su secondo boot OPNsense o M7 con trasferimento NIC, dopo prova dell'hardware. Il recupero del routing non equivale a restituire il voto di M1. M7 candidato T110 II da qualificare; H61M-K rimane fallback documentato.

FTTC e 5G hanno percorsi distinti; gestione Proxmox e Corosync restano raggiungibili localmente anche con router guasto. Metriche esterne S2 e sentinella S4 coprono il punto cieco del monitor su M1. [[REV4-MON]]

[Manuale PR9-H](https://m.media-amazon.com/images/I/91H5ClrfCBL.pdf) · [Dimensionamento OPNsense](https://docs.opnsense.org/manual/hardware.html)

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

---
codice: "INF-02.07"
titolo: "Accesso remoto e accensione inferenza"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-02.07 · Accesso remoto e accensione inferenza

## Rami, gestione e storage

La mesh/rete familiare accede al router del provider indipendentemente da M1. M1 serve la rete privata: il suo guasto può togliere DHCP/DNS/routing ai segmenti privati, non automaticamente Internet a tutta la famiglia. Preservare il Netgear GS305E disponibile.

**Collegamenti storage.** MCX312A M2:porta1 verso MNPA19 M3, porta2 verso SFP+1 M4; SFP+2 M4 allo switch. Tre link distinti10Gb E. Rete gestione/cluster separata dai linkdiretti senza gateway, disponibile anche con M4 spento. Windows su MP3 Aspire usa il proprio percorso LAN.

## Segmentazione e accesso

**Confini fisici.** M2 servizi personali e M6 servizi esterni hanno accessi distinti; Hermes MP3 e OpenClaw MP2 sono personali. M4 interno:media RO a Jellyfin e scritturaarr limitata, repository WD esclusi. Reti IoTlocale/cloud/camere su switch/AP indipendenti da M5. Vedi REV3-RET.

I percorsi diretti ai nodi non richiedono Caddy, dashboard o M2. Verificare DNS quando M1/HP sono assenti e registrare indirizzi di recupero fuori dal vault online. Il profilo di accesso remoto identifica nodo, account e autenticazione nel registro del servizio.

## Energia

**Alimentazione e disponibilita.** M3 IA e M4 media/backup hanno arresto30 min con controllo quorum residuo; M6 su richiesta senza timerstop fissato. Backup M4 giornaliero18:00. Rack power station diretta UPS, client compatti per stop e cluster arrestabile nei blackout prolungati. Vedi REV3-ENE.

**M3 - Inferenza dedicata.** X99-T8 / E5-2678 v3/128 GB RDIMM e RTX3060 per IA su Proxmox. Windows su MP3 Aspire; RTX2080 su MP4 familiare. M3 accensione IA su conferma / coda, spegnimento30 min se non necessario ad altri servizi o lavori autorizzati.

**M3 - Storage locale.** WD PC SN530 NVMe 512 GB nello slot M.2 PCIe 2.0 x4 per Proxmox e ambiente IA; NVMe 256 GB nello slot M.2 PCIe 3.0 x4 per Windows. I due storage sono gestiti dall’host e rimangono distinti. I file condivisi di Windows risiedono sul pool M2 e transitano sul collegamento 10 Gb E. Il disco Windows da 256 GB limita lo spazio locale per giochi e applicazioni.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

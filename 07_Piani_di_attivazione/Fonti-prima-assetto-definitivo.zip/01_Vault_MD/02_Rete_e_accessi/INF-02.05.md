---
codice: "INF-02.05"
titolo: "Indirizzi, DHCP e orologi"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-02.05 · Indirizzi, DHCP e orologi

## Rami, gestione e storage

La mesh/rete familiare accede al router del provider indipendentemente da M1. M1 serve la rete privata: il suo guasto può togliere DHCP/DNS/routing ai segmenti privati, non automaticamente Internet a tutta la famiglia. Preservare il Netgear GS305E disponibile.

**Collegamenti storage.** MCX312A M2:porta1 verso MNPA19 M3, porta2 verso SFP+1 M4; SFP+2 M4 allo switch. Tre link distinti10Gb E. Rete gestione/cluster separata dai linkdiretti senza gateway, disponibile anche con M4 spento. Windows su MP3 Aspire usa il proprio percorso LAN.

## Segmentazione e accesso

**Confini fisici.** M2 servizi personali e M6 servizi esterni hanno accessi distinti; Hermes MP3 e OpenClaw MP2 sono personali. M4 interno:media RO a Jellyfin e scritturaarr limitata, repository WD esclusi. Reti IoTlocale/cloud/camere su switch/AP indipendenti da M5. Vedi REV3-RET.

I percorsi diretti ai nodi non richiedono Caddy, dashboard o M2. Verificare DNS quando M1/HP sono assenti e registrare indirizzi di recupero fuori dal vault online. Il profilo di accesso remoto identifica nodo, account e autenticazione nel registro del servizio.

## Energia

**Alimentazione e disponibilita.** M3 IA e M4 media/backup hanno arresto30 min con controllo quorum residuo; M6 su richiesta senza timerstop fissato. Backup M4 giornaliero18:00. Rack power station diretta UPS, client compatti per stop e cluster arrestabile nei blackout prolungati. Vedi REV3-ENE.

## Collegamenti

[[START]] · [[REV3-ATL]] · [[REV3-SRV]] · [[REV3-STO]] · [[REV3-GST]] · [[REV3-SRC]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]

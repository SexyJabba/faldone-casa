---
codice: "INF-04.06"
titolo: "Storage: transizione e destinazioni definitive"
revisione: "4.4"
aggiornato: "2026-11-01"
tipo: "Configurazione di progetto; attuazione separata"
---

# INF-04.06 · Storage: transizione e destinazioni definitive

| Nodo/interfaccia | Supporti | Contenuto | Condizione |
| --- | --- | --- | --- |
| M1 / SATA | INV-007 Kingston V200 120 GB | Boot Proxmox/OPNsense VM | Secondo disco OPNsense bare metal da associare |
| M2 / NVMe | INV-009 Sabrent Rocket512 GB | Boot Proxmox | Locale |
| M2 / secondo NVMe | INV-005 Crucial P310 4 TB, recuperato da Arca | Servizi e dati personali; segnaposto in attesa di pool SSD | Singolo disco; nessuna ridondanza. Solo dopo copie e recupero verificati |
| M3 / M.2 PCIe2.0x4 | INV-006 WD PC SN530512 GB | Host e IA | Altro M.2 non assegnato a Windows; inventario NVMe da ricontare |
| MP3 Aspire 7 | Crucial P3 Plus 1 TB | Windows/Hermes/giochi | Rimane nelportatile, non libero per PC |
| M4 / SATA native | 6 WD10EAVS1 TB, INV-001 | WD oggi anche media; a regime solo backup versionati RAIDZ2 | Ricostruire dopo evacuazione verificata; circa 4 TB nominali, spazio versioni da dimensionare |
| M4 / LSI2308 | 4 ST2000DM0082 TB, INV-087 | Media RAIDZ1, circa 6 TB nominali | ST2000DM008 SMR: collaudo ricostruzione e carico prima adozione; circa 6 TB nominali |
| M5 / SATA | INV-003 Samsung850EVO 250 GB | Boot Proxmox e stato | Recuperabile confermato |
| M5 / SATA | 2 ST1000LM0241 TB, INV-013 | Mirror Frigate circa 1 TB nominale | 4 camere eventi 7 giorni; risultato dipende dai flussi |
| M6 / SATA | INV-004 Kingston V300 120 GB | Boot Proxmox | Boot; dati DB separati e quote sullo staging SSD, dimensionamento prima installazione |
| M6 / SATA | INV-008 Samsung850EVO 500 GB | Download e staging | Incompleti, seed, quote e margine operativo |
| M6 / SATA | 2 WD10EZRX1 TB, INV-002 | Mirror Seafile e copie audio quotate | 10x50 GB; residuo per versioni/audio/margine; nessun backup aggiuntivo cloud |
| C3 / C4 | Un SSD locale per Dell | ZFS host + VM client + repliche HA | Capacita reale da associare; singolo SSD senza ridondanza locale |
| S3 / S4 | Storage Wyse 32 GB dichiarato per esemplare | Linux, radio/testimone e stato | Riconciliare storage effettivo; gli Apacer 8 GB restano sugli HP esterni |
| M4 / S1 / M7 | Boot da associare al saldo | Avvio indipendente | Nessun acquisto prima del riconteggio |
| SH1 / Arca durante transizione | INV-005 P310 4 TB nel box Lexar E750 | Conservare finche i dati unici sono protetti; poi P310 a M2 | Il box resta libero solo dopo il passaggio; non contare due SSD |
| SH3 | INV-086 Intenso250 GB + INV-089 ORICO | Supporto esterno assegnato | Non libera riserva boot |
| MP2 Air M1 | SSD interno256 GB | Scenario Air ancora in sospeso | Non requisito della configurazione 4.3 |
| Due HP esterni | Apacer M.2 8 GB + USB | LibreELEC/configurazione + contenuti offline | Capacita USB da associare |
| Microtech ingresso | 64 GB eMMC da modello, da riscontrare | Sistema e pannello ingresso | SSD opzionale, non acquisto imposto |
| RDX SATA | Tre cartucce HP 2 TB proposte, non comprate | Selezioni offline: foto/video, documenti, lavoro | 50 EUR ciascuna offerta riferita; verificare compatibilita e stato |

## Stato reale e progetto

Oggi film e serie TV sono anche sui WD Green. La separazione WD backup / Seagate media e destinazione, non stato gia installato. I dati devono essere evacuati e confrontati prima della ricostruzione. Arca contiene il medesimo P310 che passera a M2: non esistono due unita da 4 TB.

I sei WD in RAIDZ2 offrono circa 4 TB nominali, non spazio infinito per versioni di tutti i 4 TB di M2 piu tutti i media. I quattro Seagate ST2000DM008 sono SMR: RAIDZ1 da circa 6 TB resta subordinato a prove e accettazione dei tempi di riscrittura/resilver. Un'alternativa a due mirror riduce la capacita a circa 4 TB nominali ma non elimina la natura SMR. Nessun array e dichiarato gia ricostruito.

Database ed esportazioni applicative richiedono consistenza; una copia del rootfs non comprende automaticamente mount esterni. Snapshot e mirror non sono copie indipendenti. [[REV4-MIG]] · [[REV3-BCK]]

## Navigazione

[[REV4-HOME]] · [[REV4-ROAD]] · [[REV3-OPEN]]
